<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Session.php</title>
</head>
<body>
    <header>
        <h1>Jogo Da Pontuação</h1>
<header>


<?php
session_start();


if (!isset($_SESSION['pontos'])) {
    $_SESSION['pontos'] = 0;
}


if (isset($_POST['alterar_nome'])) {
    $_SESSION['jogador'] = $_POST['jogador'];
}


if (isset($_POST['mais10'])) {
    $_SESSION['pontos'] += 10;
}


if (isset($_POST['menos10'])) {
    $_SESSION['pontos'] -= 10;

    if ($_SESSION['pontos'] < 0) {
        $_SESSION['pontos'] = 0;
    }
}


if (isset($_POST['Reiniciar'])) {
    $_SESSION['pontos'] = 0;
}

if (isset($_POST['Jogador'])){
    $_SESSION['Jogador'] = $_POST['Jogador'];
}

if (isset($_POST['reset_nome'])) {
    $_SESSION['jogador'] = "";
}

?>

<br>

<p>
    <strong>Jogador:</strong>
    <?= isset($_SESSION['jogador']) ? $_SESSION['jogador'] : "Nenhum" ?>
</p>

<form method="post">
    <button type="submit" name="reset_nome">Alterar</button>
</form>

<form method="post">
    <label>Novo nome:</label>
    <input type="text" name="jogador" required>
    <button type="submit" name="alterar_nome">Alterar nome</button>
</form>

<form method="post">
    <button type="submit" name="mais10">+10</button>
</form>

<form method="post">
    <button type="submit" name="menos10">-10</button>
</form>

<form method="post">
    <button type="submit" name="Reiniciar">Reset</button>
</form>



</body>
</html>