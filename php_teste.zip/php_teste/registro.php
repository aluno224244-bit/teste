<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { background-color: black; min-height: 100vh; display: flex; flex-direction: column; align-items: center; justify-content: center; font-family: Arial, sans-serif; }
        .mensagem-sistema { color: white; margin-bottom: 20px; font-weight: bold; font-size: 16px; text-align: center; }
        .registro { background-color: white; width: 100%; max-width: 400px; padding: 40px; border-radius: 10px; }
        .registro h1 { margin-bottom: 20px; font-size: 24px; }
        .registro_form { display: flex; flex-direction: column; gap: 15px; }
        .registro_form input { padding: 10px 14px; border: 1px solid #ccc; border-radius: 6px; font-size: 15px; outline: none; transition: border-color 0.2s; }
        .registro_form input:focus 
        { border-color: #555; }
        .registro_form button 
        { padding: 11px; background: #111; color: #fff; border: none; border-radius: 6px; font-size: 15px; cursor: pointer; transition: background 0.2s; }
        .registro_form button:hover 
        { background: #333; }
    </style>
</head>
<body>
    <div class="mensagem-sistema">
        <?php
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        error_reporting(E_ALL);

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            include "conexao.php";

            $nome = $_POST["nome"];
            $email = $_POST["gmail"];
            $pass = $_POST["pass"];
            $pass_confirm = $_POST["pass_confirm"];

            if ($pass !== $pass_confirm) {
                echo "Erro: As passwords não coincidem!";
            } else {
                
                $stmt_check_nome = mysqli_prepare($conn, "SELECT nome FROM utilizadores WHERE nome = ?");

                mysqli_stmt_bind_param($stmt_check_nome, "s", $nome);

                mysqli_stmt_execute($stmt_check_nome);

                mysqli_stmt_store_result($stmt_check_nome);

                $nome_existe = mysqli_stmt_num_rows($stmt_check_nome) > 0;
                
                
                $stmt_check_email = mysqli_prepare($conn, "SELECT email FROM utilizadores WHERE email = ?");

                mysqli_stmt_bind_param($stmt_check_email, "s", $email);

                mysqli_stmt_execute($stmt_check_email);

                mysqli_stmt_store_result($stmt_check_email);

                $email_existe = mysqli_stmt_num_rows($stmt_check_email) > 0;

                if ($nome_existe && $email_existe) {

                    echo "Erro: Este Nome de Utilizador e este E-mail já estão em uso!";

                } elseif ($nome_existe) {

                    echo "Erro: Este Nome de Utilizador já está em uso!";

                } elseif ($email_existe) {

                    echo "Erro: Este E-mail já está registado!";

                } else {
                
                    $pass_cripto = password_hash($pass, PASSWORD_DEFAULT);
                    $stmt_insert = mysqli_prepare($conn, "INSERT INTO utilizadores (nome, email, pass) VALUES (?, ?, ?)");
                    mysqli_stmt_bind_param($stmt_insert, "sss", $nome, $email, $pass_cripto);

                    if (mysqli_stmt_execute($stmt_insert)) {
                        echo "Utilizador registado com sucesso!";
                    } else {
                        echo "Erro na Base de Dados: " . mysqli_error($conn);
                    }
                    mysqli_stmt_close($stmt_insert);
                }

                mysqli_stmt_close($stmt_check_nome);
                mysqli_stmt_close($stmt_check_email);
            }
            mysqli_close($conn);
        }
        ?>
    </div>

    <section class="registro">
        <h1>Criar Conta</h1>
        <form method="post" action="" class="registro_form">
            <input name="nome" type="text" placeholder="Nome de Utilizador" required>
            <input name="gmail" type="email" placeholder="E-mail" required>
            <input name="pass" type="password" placeholder="Password" required>
            <input name="pass_confirm" type="password" placeholder="Confirmar password" required>
            <button name="SUB" type="submit" value="submit">registar</button>
        </form>
    </section>
</body>
</html>
