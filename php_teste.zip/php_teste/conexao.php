<?php
$host = "localhost";
$utilizador = "root";     
$password = "";            
$base_dados = "gestor";

$conn = mysqli_connect($host, $utilizador, $password, $base_dados);

if (!$conn) {
    die("Erro na conexão: " . mysqli_connect_error());
}
?>